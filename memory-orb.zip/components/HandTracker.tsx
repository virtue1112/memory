import React, { useEffect, useRef, useState } from 'react';
import { FilesetResolver, HandLandmarker } from '@mediapipe/tasks-vision';
import { HandState } from '../types';

interface HandTrackerProps {
  onHandUpdate: (state: HandState) => void;
  onSwipe: (direction: 'left' | 'right') => void;
}

const HandTracker: React.FC<HandTrackerProps> = ({ onHandUpdate, onSwipe }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error' | 'waiting_for_permission'>('loading');
  const handLandmarkerRef = useRef<HandLandmarker | null>(null);
  const requestRef = useRef<number | null>(null);
  
  // Gesture Tracking Refs
  const lastXRef = useRef<number[]>([]);
  const gestureCooldownRef = useRef<number>(0);

  const init = async () => {
    try {
      setStatus('loading');
      
      const vision = await FilesetResolver.forVisionTasks(
        "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.18/wasm"
      );

      handLandmarkerRef.current = await HandLandmarker.createFromOptions(vision, {
        baseOptions: {
          modelAssetPath: `https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task`,
          delegate: "GPU"
        },
        runningMode: "VIDEO",
        numHands: 1,
        minHandDetectionConfidence: 0.5,
        minHandPresenceConfidence: 0.5,
        minTrackingConfidence: 0.5
      });

      startWebcam();
    } catch (error) {
      console.error("Failed to initialize HandTracker:", error);
      setStatus('error');
    }
  };

  const startWebcam = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { 
              width: { ideal: 640 }, 
              height: { ideal: 480 },
              facingMode: "user"
          } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        
        // Wait for metadata to load to ensure dimensions are correct
        videoRef.current.onloadedmetadata = () => {
             videoRef.current?.play();
             setStatus('ready');
             predict();
        };
      }
    } catch (err) {
      console.error("Webcam access denied or failed", err);
      setStatus('waiting_for_permission');
    }
  };

  useEffect(() => {
    init();

    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
      if (videoRef.current && videoRef.current.srcObject) {
         const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
         tracks.forEach(track => track.stop());
      }
    };
  }, []);

  const detectSwipe = (x: number, isOpen: boolean) => {
    if (!isOpen) {
        lastXRef.current = [];
        return;
    }

    const now = Date.now();
    if (now - gestureCooldownRef.current < 800) return; 

    lastXRef.current.push(x);
    if (lastXRef.current.length > 8) lastXRef.current.shift();

    if (lastXRef.current.length >= 5) {
      const first = lastXRef.current[0];
      const last = lastXRef.current[lastXRef.current.length - 1];
      const diff = last - first;

      // Relaxed threshold
      if (diff > 0.25) {
        onSwipe('left'); 
        gestureCooldownRef.current = now;
        lastXRef.current = [];
      } else if (diff < -0.25) {
        onSwipe('right');
        gestureCooldownRef.current = now;
        lastXRef.current = [];
      }
    }
  };

  const drawLandmarks = (landmarks: any[]) => {
      if (!canvasRef.current || !videoRef.current) return;
      const ctx = canvasRef.current.getContext('2d');
      if (!ctx) return;

      // Clear
      ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
      
      // Match canvas size to video
      if (canvasRef.current.width !== videoRef.current.videoWidth) {
          canvasRef.current.width = videoRef.current.videoWidth;
          canvasRef.current.height = videoRef.current.videoHeight;
      }

      ctx.fillStyle = '#00FF00';
      ctx.strokeStyle = '#00FF00';
      ctx.lineWidth = 2;

      landmarks.forEach((point) => {
          const x = (1 - point.x) * canvasRef.current!.width; // Mirror
          const y = point.y * canvasRef.current!.height;
          
          ctx.beginPath();
          ctx.arc(x, y, 4, 0, 2 * Math.PI);
          ctx.fill();
      });
  };

  const predict = () => {
    if (videoRef.current && handLandmarkerRef.current && videoRef.current.readyState >= 2) {
      const nowInMs = performance.now();
      const results = handLandmarkerRef.current.detectForVideo(videoRef.current, nowInMs);

      if (results.landmarks && results.landmarks.length > 0) {
        const landmarks = results.landmarks[0];
        
        drawLandmarks(landmarks);

        // 1. Open/Close (Avg Distance)
        const wrist = landmarks[0];
        const tips = [8, 12, 16, 20]; // Fingertips
        let avgDist = 0;
        tips.forEach(idx => {
           const dx = landmarks[idx].x - wrist.x;
           const dy = landmarks[idx].y - wrist.y;
           avgDist += Math.sqrt(dx*dx + dy*dy);
        });
        avgDist /= tips.length;
        
        // Relaxed Thresholds for better detection
        const isOpen = avgDist > 0.2; 
        const isClosed = avgDist < 0.12; // Easier to trigger Fist

        // 2. Pinch (Thumb 4, Index 8)
        const thumbTip = landmarks[4];
        const indexTip = landmarks[8];
        const pinchDist = Math.sqrt(
            Math.pow(thumbTip.x - indexTip.x, 2) + 
            Math.pow(thumbTip.y - indexTip.y, 2)
        );
        // Relaxed pinch threshold
        const isPinched = pinchDist < 0.08; 

        // 3. Normalized Coordinates
        const palm = landmarks[9];
        // Mirror X for intuitive interaction (Move right hand right -> Cursor goes right)
        // MediaPipe x is 0(left) to 1(right). 
        // If we mirror the VIDEO via CSS, visually:
        // Real Right Hand -> Right side of screen.
        // Screen Right is x=1. 
        // MediaPipe raw x for Real Right Hand (appearing on right of screen) is 0 (because camera mirrors).
        // Let's standardise: x ranges -1 to 1.
        
        const x = (1 - palm.x) * 2 - 1; 
        const y = -(palm.y * 2 - 1); 

        detectSwipe(x, isOpen);

        onHandUpdate({
          isDetected: true,
          isOpen,
          isClosed,
          isPinched,
          position: { x, y, z: palm.z }
        });
      } else {
        // Clear canvas if no hand
        const ctx = canvasRef.current?.getContext('2d');
        ctx?.clearRect(0, 0, canvasRef.current?.width || 0, canvasRef.current?.height || 0);

        onHandUpdate({
          isDetected: false,
          isOpen: true,
          isClosed: false,
          isPinched: false,
          position: { x: 0, y: 0, z: 0 }
        });
      }
    }
    requestRef.current = requestAnimationFrame(predict);
  };

  return (
    <div className="fixed bottom-4 left-4 z-50 flex flex-col items-center">
       {status === 'waiting_for_permission' && (
         <button 
           onClick={init}
           className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-full shadow-lg text-xs uppercase tracking-wider animate-pulse mb-2"
         >
           Enable Camera
         </button>
       )}
       
       <div className={`relative rounded-lg overflow-hidden transition-all duration-500 ${status === 'ready' ? 'opacity-80 hover:opacity-100' : 'opacity-0'} border border-white/20 shadow-lg`}>
        {/* Video element - mirrored via CSS */}
        <video 
            ref={videoRef} 
            className="w-40 h-32 bg-black object-cover transform scale-x-[-1]" 
            playsInline 
            muted
        ></video>
        {/* Canvas overlay for debug points - standard orientation (we draw mirrored coordinates manually) */}
        <canvas
            ref={canvasRef}
            className="absolute inset-0 w-full h-full pointer-events-none"
        />
        <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-[10px] text-white/90 px-2 py-1 text-center">
            {status === 'ready' ? 'Tracking Active' : 'Initializing...'}
        </div>
      </div>
    </div>
  );
};

export default HandTracker;