import { MusicalParams } from '../types';

class AudioEngine {
  private ctx: AudioContext | null = null;
  private isPlaying: boolean = false;
  private masterGain: GainNode | null = null;
  private melodyInterval: number | null = null;
  private reverbNode: ConvolverNode | null = null;
  private padNodes: AudioNode[] = [];
  
  // Scales in semitones
  private scales = {
    major: [0, 2, 4, 5, 7, 9, 11, 12],
    minor: [0, 2, 3, 5, 7, 8, 10, 12],
    pentatonic: [0, 2, 4, 7, 9, 12],
    chromatic: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    wholeTone: [0, 2, 4, 6, 8, 10, 12]
  };

  constructor() {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioContextClass) {
      this.ctx = new AudioContextClass();
    }
  }

  // Resume context safely
  public async resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      await this.ctx.resume();
    }
  }

  private async setupEffects() {
    if (!this.ctx) return;
    
    // High Quality Reverb
    if (!this.reverbNode) {
      this.reverbNode = this.ctx.createConvolver();
      const rate = this.ctx.sampleRate;
      const length = rate * 3; 
      const decay = 2.0;
      const impulse = this.ctx.createBuffer(2, length, rate);
      const impulseL = impulse.getChannelData(0);
      const impulseR = impulse.getChannelData(1);

      for (let i = 0; i < length; i++) {
        const n = i / length;
        const rand = (Math.random() * 2 - 1) * Math.pow(1 - n, decay);
        impulseL[i] = rand;
        impulseR[i] = rand;
      }
      this.reverbNode.buffer = impulse;
    }
  }

  public async play(params: MusicalParams) {
    if (!this.ctx) return;
    await this.resume();
    
    this.stop(); 
    await this.setupEffects();
    this.isPlaying = true;

    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.setValueAtTime(0, this.ctx.currentTime);
    this.masterGain.gain.linearRampToValueAtTime(0.6, this.ctx.currentTime + 2); // Slow fade in
    
    // Routing
    this.masterGain.connect(this.reverbNode!);
    this.reverbNode!.connect(this.ctx.destination);
    // Less dry signal for more ethereal sound
    this.masterGain.connect(this.ctx.destination); 

    this.startPad(params);
    this.startGenerativeMelody(params);
  }

  public stop() {
    this.isPlaying = false;
    
    if (this.melodyInterval) {
      window.clearInterval(this.melodyInterval);
      this.melodyInterval = null;
    }

    // Stop Pads
    this.padNodes.forEach(node => {
        try { node.disconnect(); } catch(e) {}
    });
    this.padNodes = [];

    if (this.masterGain) {
        // Fade out
        try {
            this.masterGain.gain.setTargetAtTime(0, this.ctx?.currentTime || 0, 0.5);
            setTimeout(() => {
                this.masterGain?.disconnect();
                this.masterGain = null;
            }, 600);
        } catch(e) {}
    }
  }

  // Background Ambient Pad (Choir-ish)
  private startPad(params: MusicalParams) {
      if (!this.ctx || !this.masterGain) return;
      const t = this.ctx.currentTime;
      
      const rootFreq = params.baseFrequency / 2; // Lower octave
      const frequencies = [rootFreq, rootFreq * 1.5]; // Root and Fifth

      frequencies.forEach((freq, i) => {
          const osc = this.ctx!.createOscillator();
          osc.type = 'sawtooth'; // Richer harmonics
          osc.frequency.value = freq;

          // Lowpass filter to smooth it into a "hum" or "voice"
          const filter = this.ctx!.createBiquadFilter();
          filter.type = 'lowpass';
          filter.frequency.value = 500 + Math.random() * 200;
          filter.Q.value = 1;

          const gain = this.ctx!.createGain();
          gain.gain.value = 0.15; // Low volume background
          
          // Slight detune LFO for chorus effect
          const lfo = this.ctx!.createOscillator();
          lfo.frequency.value = 0.1 + Math.random() * 0.1;
          const lfoGain = this.ctx!.createGain();
          lfoGain.gain.value = 3; // Detune amount
          lfo.connect(lfoGain);
          lfoGain.connect(osc.detune);

          osc.connect(filter);
          filter.connect(gain);
          gain.connect(this.masterGain!);

          osc.start(t);
          lfo.start(t);

          this.padNodes.push(osc, filter, gain, lfo, lfoGain);
      });
  }

  // Synthesis: FM Electric Piano / Bell sound
  private playNote(freq: number, velocity: number, duration: number) {
      if (!this.ctx || !this.masterGain) return;
      const t = this.ctx.currentTime;

      // 1. Operator (Modulator)
      const modulator = this.ctx.createOscillator();
      const modGain = this.ctx.createGain();
      
      modulator.frequency.value = freq * 2.0; 
      modulator.type = 'sine';

      // 2. Carrier (Fundamental)
      const carrier = this.ctx.createOscillator();
      carrier.type = 'sine';
      carrier.frequency.value = freq;

      // 3. Envelope
      const env = this.ctx.createGain();
      
      // Wiring
      modulator.connect(modGain);
      modGain.connect(carrier.frequency);
      carrier.connect(env);
      env.connect(this.masterGain);

      // FM Envelope
      const modIndex = 300 * velocity; 
      modGain.gain.setValueAtTime(modIndex, t);
      modGain.gain.exponentialRampToValueAtTime(1, t + 0.3);

      // Amplitude Envelope
      env.gain.setValueAtTime(0, t);
      env.gain.linearRampToValueAtTime(velocity * 0.3, t + 0.05); // Softer Attack
      env.gain.exponentialRampToValueAtTime(0.001, t + duration); // Long Decay

      modulator.start(t);
      carrier.start(t);
      
      modulator.stop(t + duration);
      carrier.stop(t + duration);

      // Clean up nodes after playing
      setTimeout(() => {
          modulator.disconnect();
          carrier.disconnect();
          env.disconnect();
      }, duration * 1000 + 100);
  }

  private startGenerativeMelody(params: MusicalParams) {
    if (!this.ctx) return;

    // Calculate timings
    // Slow down the tempo slightly for more "beautiful/emotional" feel
    const beatTime = 60 / (params.tempo * 0.8); 
    const scale = this.scales[params.scale];
    
    let tick = 0;

    this.melodyInterval = window.setInterval(() => {
      if (!this.isPlaying) return;
      tick++;

      // 1. Bass / Chord progression (Slow)
      if (tick % 4 === 0) {
          const offset = scale[Math.floor(Math.random() * 3)];
          const bassFreq = params.baseFrequency * Math.pow(2, offset/12) / 2;
          this.playNote(bassFreq, 0.4, 4.0);
          
          if (Math.random() > 0.6) {
             this.playChord(bassFreq * 2, scale, 2);
          }
      }

      // 2. Melody
      // Higher probability of notes to avoid silence
      if (Math.random() < Math.max(0.3, params.complexity)) {
          let noteIndex = Math.floor(Math.random() * scale.length);
          
          if (params.mood === 'uplifting') {
              noteIndex = (tick % scale.length);
          } else if (params.mood === 'melancholic') {
              noteIndex = Math.floor(Math.random() * (scale.length / 2));
          }

          let octave = 1;
          if (params.mood === 'ethereal') octave = 2; 
          if (Math.random() > 0.85) octave = 2;

          const freq = params.baseFrequency * Math.pow(2, scale[noteIndex]/12) * octave;
          
          // Smoother velocity
          const velocity = 0.2 + Math.random() * 0.4;
          this.playNote(freq, velocity, 3.0);
      }

    }, beatTime * 1000); 
  }

  private playChord(root: number, scale: number[], count: number) {
      for(let i=0; i<count; i++) {
          const interval = scale[(i * 2) % scale.length];
          const freq = root * Math.pow(2, interval/12);
          setTimeout(() => {
            this.playNote(freq, 0.2, 4.0);
          }, i * 100); 
      }
  }

  public getIsPlaying() {
    return this.isPlaying;
  }
}

export const audioEngine = new AudioEngine();