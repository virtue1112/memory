import React, { useState, useEffect, useRef } from 'react';
import HandTracker from './components/HandTracker';
import ParticleOrb from './components/ParticleOrb';
import ChatBot from './components/ChatBot';
import RainBackground from './components/RainBackground';
import { generateMemoryMetadata } from './services/aiService';
import { audioEngine } from './services/audioEngine';
import { HandState, Memory } from './types';

const App: React.FC = () => {
  // State
  const [view, setView] = useState<'create' | 'orb'>('create');
  const [memories, setMemories] = useState<Memory[]>([]);
  const [currentMemoryIndex, setCurrentMemoryIndex] = useState<number>(-1);
  const [handState, setHandState] = useState<HandState>({ isDetected: false, isOpen: true, isClosed: false, isPinched: false, position: { x: 0, y: 0, z: 0 } });
  
  // Orb State
  const [orbShapeIndex, setOrbShapeIndex] = useState(0);
  const lastShapeChangeRef = useRef(0);
  const lastActionRef = useRef(0);

  // Creation Form State
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [diaryEntry, setDiaryEntry] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  // Appearance & Settings State
  const [density, setDensity] = useState(0.5);
  const [fontColor, setFontColor] = useState('#e0e0e0');
  const [backgroundMedia, setBackgroundMedia] = useState<{url: string | null, isVideo: boolean}>({ url: null, isVideo: false });
  const [showLeftSidebar, setShowLeftSidebar] = useState(false);

  // Computed
  const activeMemory = currentMemoryIndex >= 0 && memories.length > 0 ? memories[currentMemoryIndex] : null;

  // Ensure audio context is ready on first interaction
  useEffect(() => {
      const unlockAudio = () => {
          audioEngine.resume();
          window.removeEventListener('click', unlockAudio);
          window.removeEventListener('touchstart', unlockAudio);
      };
      window.addEventListener('click', unlockAudio);
      window.addEventListener('touchstart', unlockAudio);
      return () => {
          window.removeEventListener('click', unlockAudio);
          window.removeEventListener('touchstart', unlockAudio);
      };
  }, []);

  // Handlers
  const handleHandUpdate = (state: HandState) => {
    setHandState(state);
    
    // Gesture Logic
    const now = Date.now();
    if (now - lastActionRef.current > 1500) { 
        
        // 1. Fist (Grab) -> Toggle Play
        // Must be in orb view
        if (state.isClosed && view === 'orb') {
             toggleMusic();
             lastActionRef.current = now;
        }
    }

    // 2. Pinch -> Mutate Shape
    if (state.isPinched && view === 'orb') {
        if (now - lastShapeChangeRef.current > 1000) {
            mutateShape();
            lastShapeChangeRef.current = now;
        }
    }
  };

  const mutateShape = () => {
      let newShape = Math.floor(Math.random() * 5);
      while(newShape === orbShapeIndex) {
          newShape = Math.floor(Math.random() * 5);
      }
      setOrbShapeIndex(newShape);
  };

  const handleSwipe = (direction: 'left' | 'right') => {
    if (view === 'orb' && memories.length > 1) {
      if (direction === 'left') nextMemory();
      if (direction === 'right') prevMemory();
    }
  };

  const nextMemory = () => {
    if (memories.length === 0) return;
    const newIndex = (currentMemoryIndex + 1) % memories.length;
    setCurrentMemoryIndex(newIndex);
    // Stop previous music to allow user to choose when to play new one, or auto-play?
    // User requested "auto play" in previous prompt: "Selecting this sphere can automatically play".
    // Swipe == Select. So let's auto-play if it was already playing, or just play.
    
    // Restart music for new memory
    if (isPlaying) {
         // Brief pause for transition
         audioEngine.stop();
         setTimeout(() => {
             if (memories[newIndex]) playMemoryMusic(memories[newIndex]);
         }, 100);
    }
    setOrbShapeIndex(0); 
  };

  const prevMemory = () => {
    if (memories.length === 0) return;
    const newIndex = (currentMemoryIndex - 1 + memories.length) % memories.length;
    setCurrentMemoryIndex(newIndex);
    if (isPlaying) {
         audioEngine.stop();
         setTimeout(() => {
             if (memories[newIndex]) playMemoryMusic(memories[newIndex]);
         }, 100);
    }
    setOrbShapeIndex(0);
  };

  const playMemoryMusic = async (mem: Memory) => {
     try {
        await audioEngine.play(mem.musicalParams);
        setIsPlaying(true);
     } catch (e) {
         console.error("Audio playback failed", e);
     }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setSelectedImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleBackgroundUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const isVideo = file.type.startsWith('video');
          const url = URL.createObjectURL(file);
          setBackgroundMedia({ url, isVideo });
      }
  };

  const handleCreateMemory = async () => {
    if (!selectedImage || !diaryEntry) return;

    setIsProcessing(true);
    await audioEngine.resume(); // Ensure context is awake
    
    const dateStr = new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    
    const metadata = await generateMemoryMetadata(diaryEntry, dateStr);

    const newMemory: Memory = {
      id: Date.now().toString(),
      imageUrl: selectedImage,
      diary: diaryEntry,
      date: dateStr,
      keywords: metadata.keywords,
      musicalParams: metadata.musicalParams,
      title: metadata.title
    };

    const updatedMemories = [newMemory, ...memories];
    setMemories(updatedMemories);
    setCurrentMemoryIndex(0); // Set to newest
    setView('orb');
    
    // Reset Form
    setSelectedImage(null);
    setDiaryEntry('');
    setIsProcessing(false);
    
    await playMemoryMusic(newMemory);
  };

  const handleAddMemory = () => {
    setView('create');
    setSelectedImage(null);
    setDiaryEntry('');
    audioEngine.stop();
    setIsPlaying(false);
  };

  const toggleMusic = async () => {
    if (!activeMemory) return;

    if (isPlaying) {
      audioEngine.stop();
      setIsPlaying(false);
    } else {
      await playMemoryMusic(activeMemory);
    }
  };

  return (
    <div className="relative w-full h-screen bg-black overflow-hidden font-sans selection:bg-indigo-500/30 cursor-none" style={{ color: fontColor }}>
      
      <RainBackground mediaUrl={backgroundMedia.url} isVideo={backgroundMedia.isVideo} />

      <div className="absolute inset-0 z-0">
        <ParticleOrb 
          imageUrl={activeMemory?.imageUrl || (selectedImage || '')} 
          isActive={view === 'orb' || !!selectedImage}
          handState={handState}
          isMusicPlaying={isPlaying}
          density={density}
          shapeIndex={orbShapeIndex}
        />
      </div>

      <HandTracker onHandUpdate={handleHandUpdate} onSwipe={handleSwipe} />

      {/* Visual Hand Cursor */}
      {handState.isDetected && (
          <div 
            className="fixed w-6 h-6 border-2 border-white rounded-full pointer-events-none z-[100] transition-transform duration-75 mix-blend-difference flex items-center justify-center"
            style={{ 
                left: '50%', 
                top: '50%',
                transform: `translate(calc(-50% + ${handState.position.x * 50}vw), calc(-50% + ${handState.position.y * 50}vh)) scale(${handState.isClosed ? 0.5 : handState.isPinched ? 0.8 : 1})`
            }}
          >
             {/* Inner dot */}
             <div className={`w-1 h-1 bg-white rounded-full ${handState.isClosed ? 'bg-red-500' : ''}`} />
             {/* Status Text near cursor */}
             <div className="absolute top-8 text-[10px] font-bold tracking-widest uppercase text-white whitespace-nowrap opacity-70">
                 {handState.isClosed ? 'GRAB' : handState.isPinched ? 'MORPH' : ''}
             </div>
          </div>
      )}

      {/* UI Overlay */}
      <div className="absolute inset-0 z-10 flex flex-col pointer-events-none cursor-auto">
        
        {/* Header */}
        <header className="p-6 flex justify-between items-center pointer-events-auto">
          <h1 className="text-3xl font-serif italic tracking-wider drop-shadow-lg" style={{ color: fontColor }}>Memory Orb</h1>
          <button onClick={() => setShowLeftSidebar(!showLeftSidebar)} className="md:hidden text-white"><span className="material-symbols-outlined">menu</span></button>
        </header>

        {/* Left Customization Sidebar */}
        <div className={`absolute left-6 top-1/2 -translate-y-1/2 pointer-events-auto transition-transform duration-300 ${showLeftSidebar ? 'translate-x-0' : '-translate-x-[150%]'} md:translate-x-0`}>
            <div className="bg-black/40 backdrop-blur-md p-4 rounded-2xl border border-white/10 flex flex-col gap-4 w-16 group hover:w-64 transition-all duration-300 overflow-hidden">
                <div className="flex items-center gap-4">
                     <span className="material-symbols-outlined text-white/70">palette</span>
                     <span className="text-xs uppercase tracking-widest whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">Text Color</span>
                </div>
                <input type="color" value={fontColor} onChange={(e) => setFontColor(e.target.value)} className="w-8 h-8 rounded-full cursor-pointer bg-transparent border-none" />
                
                <div className="h-px bg-white/10 w-full" />
                
                <div className="flex items-center gap-4">
                     <span className="material-symbols-outlined text-white/70">wallpaper</span>
                     <span className="text-xs uppercase tracking-widest whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">Background</span>
                </div>
                <label className="cursor-pointer">
                    <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20"><span className="material-symbols-outlined text-sm">upload</span></div>
                    <input type="file" accept="image/*,video/*" className="hidden" onChange={handleBackgroundUpload} />
                </label>
            </div>
        </div>

        {/* Right Sidebar Controls */}
        <div className="absolute right-6 top-1/2 -translate-y-1/2 flex flex-col items-center gap-6 pointer-events-auto bg-black/20 backdrop-blur-sm p-4 rounded-full border border-white/10">
          <button onClick={handleAddMemory} className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/30 flex items-center justify-center transition-all border border-white/20" title="Add New Memory">
            <span className="material-symbols-outlined text-xl">add</span>
          </button>
          <div className="h-48 w-2 relative flex justify-center">
             <input type="range" min="0" max="1" step="0.01" value={density} onChange={(e) => setDensity(parseFloat(e.target.value))}
                className="absolute w-48 -rotate-90 origin-center top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 appearance-none bg-white/20 h-1 rounded-full [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white cursor-pointer" />
          </div>
          <div className="text-[10px] uppercase tracking-widest text-white/50 rotate-90 whitespace-nowrap">Density</div>
        </div>

        {/* Navigation Arrows (Carousel) */}
        {view === 'orb' && memories.length > 1 && (
            <>
                <button onClick={prevMemory} className="absolute left-4 md:left-24 top-1/2 -translate-y-1/2 pointer-events-auto w-12 h-12 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center backdrop-blur-sm transition-all hover:scale-110">
                    <span className="material-symbols-outlined text-3xl">chevron_left</span>
                </button>
                <button onClick={nextMemory} className="absolute right-4 md:right-24 top-1/2 -translate-y-1/2 pointer-events-auto w-12 h-12 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center backdrop-blur-sm transition-all hover:scale-110">
                    <span className="material-symbols-outlined text-3xl">chevron_right</span>
                </button>
            </>
        )}

        {/* Main Content Area */}
        <main className="flex-1 flex items-center justify-center p-6 relative">
          
          {/* Create View */}
          {view === 'create' && (
            <div className="transition-all duration-700 w-full max-w-lg translate-y-0">
              {!selectedImage && (
                <div className="text-center pointer-events-auto bg-black/40 backdrop-blur-sm p-10 rounded-3xl border border-white/10 animate-fade-in">
                  <label className="cursor-pointer group flex flex-col items-center gap-4">
                    <div className="w-20 h-20 rounded-full border-2 border-dashed border-white/30 group-hover:border-white flex items-center justify-center transition-all">
                      <span className="material-symbols-outlined text-3xl text-white/50 group-hover:text-white">add_a_photo</span>
                    </div>
                    <span className="text-lg font-light">Upload a visual memory</span>
                    <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                  </label>
                </div>
              )}
              {selectedImage && (
                <div className="pointer-events-auto bg-black/60 backdrop-blur-md p-8 rounded-3xl border border-white/10 animate-slide-up shadow-2xl">
                  <h2 className="text-xl font-serif mb-4">What do you remember?</h2>
                  <textarea 
                    value={diaryEntry}
                    onChange={(e) => setDiaryEntry(e.target.value)}
                    placeholder="Write your diary entry here..."
                    className="w-full h-32 bg-transparent border-b border-white/20 focus:border-white focus:outline-none resize-none mb-6 font-light text-lg leading-relaxed placeholder-white/30"
                  />
                  <button onClick={handleCreateMemory} disabled={!diaryEntry || isProcessing} className="w-full py-4 bg-white/10 hover:bg-white/20 rounded-xl transition-all font-semibold uppercase tracking-widest disabled:opacity-50 disabled:cursor-not-allowed flex justify-center items-center gap-2">
                    {isProcessing ? <><span className="material-symbols-outlined animate-spin">refresh</span> Crystallizing...</> : 'Create Orb'}
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Orb View (Info Overlay) */}
          {view === 'orb' && activeMemory && (
            <div className="pointer-events-auto text-center space-y-4 animate-fade-in absolute bottom-[5vh] left-1/2 -translate-x-1/2 w-full max-w-2xl px-4 flex flex-col items-center">
              
              <button onClick={toggleMusic} className="w-16 h-16 rounded-full bg-white/10 backdrop-blur-md border border-white/20 hover:bg-white/20 hover:scale-105 transition-all flex items-center justify-center mb-4">
                <span className="material-symbols-outlined text-3xl">{isPlaying ? 'pause' : 'play_arrow'}</span>
              </button>

              <h2 className="text-4xl md:text-5xl font-serif italic text-white drop-shadow-lg" style={{ color: fontColor }}>
                {activeMemory.title}
              </h2>
              
              <div className="inline-block px-4 py-1 border-y border-white/30">
                  <span className="text-sm font-medium tracking-[0.3em] uppercase" style={{ color: '#FFD700' }}>
                      {activeMemory.date}
                  </span>
              </div>
              
              {/* Full Diary Display with scrolling */}
              <div className="max-h-32 overflow-y-auto w-full text-center px-4 mt-2 scrollbar-thin scrollbar-thumb-white/20 scrollbar-track-transparent">
                  <p className="text-lg font-light leading-relaxed text-white/90 italic shadow-black drop-shadow-md">
                      "{activeMemory.diary}"
                  </p>
              </div>

              <div className="flex flex-wrap justify-center gap-2 mt-2">
                {activeMemory.keywords.map((kw, i) => (
                  <span key={i} className="px-3 py-1 rounded-full border border-white/20 text-xs bg-black/20 backdrop-blur-sm">#{kw}</span>
                ))}
              </div>
              
              {/* Gesture Hint */}
              <div className="mt-4 text-[10px] uppercase tracking-widest text-white/40 flex gap-4">
                  <span className={handState.isClosed ? 'text-white font-bold' : ''}>✊ Grab to Play</span>
                  <span className={handState.isPinched ? 'text-white font-bold' : ''}>🤏 Pinch to Morph</span>
                  <span>👋 Swipe to Browse</span>
              </div>
            </div>
          )}
        </main>
      </div>

      <ChatBot />
      
    </div>
  );
};

export default App;